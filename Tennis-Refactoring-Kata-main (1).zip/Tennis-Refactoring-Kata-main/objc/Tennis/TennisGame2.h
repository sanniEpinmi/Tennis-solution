#import <Foundation/Foundation.h>
#import "TennisGame.h"

@interface TennisGame2 : TennisGame
@end