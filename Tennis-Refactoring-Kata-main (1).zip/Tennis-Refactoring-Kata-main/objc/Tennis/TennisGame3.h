#import <Foundation/Foundation.h>
#import "TennisGame.h"

@interface TennisGame3 : TennisGame
@end