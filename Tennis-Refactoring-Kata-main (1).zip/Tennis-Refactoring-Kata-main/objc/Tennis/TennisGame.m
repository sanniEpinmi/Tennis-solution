
#import "TennisGame.h"

@implementation TennisGame

- (id)initWithPlayer1:(NSString *)player1 player2:(NSString *)player2 { return [super init]; }
- (void)wonPoint:(NSString *)playerName {}
- (NSString *)score { return nil; }

@end