#import <Foundation/Foundation.h>
#import "TennisGame.h"

@interface TennisGame1 : TennisGame
@end