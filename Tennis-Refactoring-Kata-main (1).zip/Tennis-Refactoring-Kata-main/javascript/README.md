# Tennis in JavaScript

Tests are available to be run both with node.js and in the browser.
For node, simply call
  node TennisTest.js
(Only failures will be shown on the console)

For the browser, open TennisTest.html and refresh after change.