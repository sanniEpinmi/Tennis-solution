This project is now is using [.NET Core](https://www.microsoft.com/net/download)

- To build solution type: `dotnet build`
- To run the tests type: `dotnet test`

