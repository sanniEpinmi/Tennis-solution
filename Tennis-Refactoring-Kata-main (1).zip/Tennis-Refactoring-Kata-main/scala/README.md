## Tennis in scala

To run all tests continuously type `sbt "~test"` in the console in the `scala` directory.


